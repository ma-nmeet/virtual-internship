# Virtual-Internship-Tasks
This is a repo for virtual interships tasks for web devlopment internship provided by KIET Group of Institutions
